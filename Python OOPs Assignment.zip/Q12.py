#!/usr/bin/env python
# coding: utf-8

# In[16]:


class isosceles_triangle:
    def __init__(self, a, b):
        self.a = a
        self.b = b

class right_triangle:
    def __init__(self, c):
        self.c = c
    
class isosceles_right_triangle(isosceles_triangle,right_triangle):
    def __init__(self, x, y, z):
        isosceles_triangle.__init__(self, x, y)
        right_triangle.__init__(self, z)
        
    def check(self):
        if(self.a == 90 or self.b == 90 or self.c == 90):
            return "right triangle"
        
        if(self.a == self.b or self.b == self.c or self.c == self.a):
            return "isosceles trianlge"
        
        
        
t1 = isosceles_right_triangle(50,60,50)
t1.check()


# In[ ]:




