#!/usr/bin/env python
# coding: utf-8

# In[7]:


M = {
    "test1": {'Dhoni': 56, 'Balaji': 85},
    "test2": {'Dhoni': 87, 'Balaji': 200}
}

def Max_Score(s):
    total = {}
    for i in s.keys():
        for j in s[i].keys():
            if j in total.keys():
                total[j] = total[j] + s[i][j]
            else:
                total[j] = s[i][j]
                
    print("Total Run Scored by Each Playes in 2 Tests: ")
    print(total)
    
    print("Player With highest score")
    MaxScore = 0
    for n in total.keys():
        if total[n] >= MaxScore:
            name = n
            MaxScore = total[n]

    return (name, MaxScore)

score = Max_Score(M)
print(score)


# In[ ]:




