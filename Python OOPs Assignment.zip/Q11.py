#!/usr/bin/env python
# coding: utf-8

# In[8]:


class Triangle:
    def __init__(self, a, b, c):
        self.a, self.b, self.c = a, b, c
        print(self.check_angles())
        
        
    def check_angles(self):
        if sum((self.a, self.b, self.c)) == 180:
            return True
        return False
    
    
    
    def type_of_triangle(self):
        if((a>c+b) or (b>a+c) or (c>a+b)):
            return "Obtuse"
        if((a<c+b) or (b<a+c) or (c<a+b)):
            return "Acute"
        


class Isosceles_triangle(Triangle):
    def __init__(self, a, b, c):
        super().__init__(a, b, c)
    
    def check(self):
        if(self.a == self.b or self.b == self.c or self.c == self.a):
            return True
        return False


class Right_triangle(Triangle):
    def __init__(self, a, b, c):
        super().__init__(a, b, c)
    
    def check(self):
        if(self.a == 90 or self.b == 90 or self.c == 90):
            return True
        return False


class Equilateral_triangle(Triangle):
    def __init__(self, a, b, c):
        super().__init__(a, b, c)
    
    def check(self):
        if(self.a == self.b == self.c):
            return True
        return False



t1 = Isosceles_triangle(60, 60, 60)
print(t1.check())
t2 = Right_triangle(90, 30, 60)
print(t2.check())
t3 = Equilateral_triangle(60, 60, 60)
print(t3.check())
t1 = Isosceles_triangle(70, 55, 56)
print(t1.check())
t2 = Right_triangle(60, 60, 60)
print(t2.check())
t3 = Equilateral_triangle(60, 59, 61)
print(t3.check())


# In[ ]:




