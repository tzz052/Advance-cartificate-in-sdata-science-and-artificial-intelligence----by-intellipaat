#!/usr/bin/env python
# coding: utf-8

# In[6]:


class student:
    
    def __init__(self,name,age):
        self._name = name
        self._age = age
        
    def _info(self):
        print(f"My name is {self._name}. I am {self._age} old.")
        
    def acessprotectedfunction(self):
        self._info()
    
class child1:
    def __init__(self,name,age):
        self.__name = name
        self.__age = age
        
    def __info(self):
        print(f"My name is {self.__name}. I am {self.__age} old.")
        
    def acessprivatefunction(self):
        self.__info()
        
        
std = student("tapan",21)
std1 = child1("harsh",25)
        
std.acessprotectedfunction()
std1.acessprivatefunction()


# In[ ]:




