#!/usr/bin/env python
# coding: utf-8

# In[13]:


from random import random

class Vehicle:
    def __init__(self):
        self.fare = None
    
    def Fare(self, fare):
        self.fare = fare

bus = Vehicle()
car = Vehicle()
train = Vehicle()
truck = Vehicle()
ship = Vehicle()

vehicles = [bus, car, train, truck, ship]

for i in vehicles:
    i.Fare(int(random() * 10))

TotalFare = sum([i.fare for j in vehicles])
print(TotalFare)


# In[ ]:




