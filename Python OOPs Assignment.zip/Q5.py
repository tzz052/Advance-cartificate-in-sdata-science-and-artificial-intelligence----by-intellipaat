#!/usr/bin/env python
# coding: utf-8

# In[2]:


Car_0 = {}
Car_0['color'] = 'black'
Car_0['speed'] = 'medium'
Car_0['x_position'] = 10
Car_0['y_position'] = 72

if Car_0['speed'] == 'slow':
    Car_0['x_position'] += 2

elif Car_0['speed'] == 'medium':
    Car_0['x_position'] += 9
    
elif Car_0['speed'] == 'fast':
    Car_0['x_position'] +=22
    
print(Car_0)


# In[ ]:




