#!/usr/bin/env python
# coding: utf-8

# In[3]:


def square_num(n):
  return n * n
lst = list(range(1,51))
print("Original List: ",lst)
result = map(square_num, lst)
print("Square of each elements in list: ")
print(list(result))


# In[ ]:




