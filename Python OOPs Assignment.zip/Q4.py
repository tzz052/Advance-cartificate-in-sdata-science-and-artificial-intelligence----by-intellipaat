#!/usr/bin/env python
# coding: utf-8

# In[1]:


import random

deck = []
ranks = ["Ace","2","3","4","5","6","7","8","9","10","Jack","Queen","King"]
suits = ["Clubs","Hearts","Diamonds","Spades"]

value = 1
for rank in ranks:
    for suit in suits:
        deck.append([rank + " of " + suit, value])
    value = value + 1
    
random.shuffle(deck)
score = 0
card1 = deck.pop(0)
n=0

while n<8:
    
    print("Your score so far is", score)
    print("\n\nThe current card is", card1[0])
    
    while True:
        choice = input("higher or lower?")
        if len(choice) > 0:
            if choice[0].lower() in ["h","l"]:
                break
        

    card2 = deck.pop(0)
    print("The next card picked is", card2[0])
    

    if choice[0].lower() == "h" and card2[1] > card1[1]:
        print("Correct!")
        score = score + 20
        
    if choice[0].lower() == "h" and card2[1] < card1[1]:
        print("Wrong!")
        score = score - 15
        
    if choice[0].lower() == "l" and card2[1] < card1[1]:
        print("Correct!")
        score = score + 20 
        
    if choice[0].lower() == "l" and card2[1] > card1[1]:
        print("Wrong!")
        score = score - 15
        
    if choice[0].lower() == "h" and card2[1] == card1[1]:
        print("draw")
        score = score - 15
        
    elif choice[0].lower() == "l" and card2[1] == card1[1]:
        print("draw")
        score = score - 15
    
    
    n=n+1
    card1 = card2
    


print("Game over!")
print("You final score is", score)


# In[ ]:





# In[ ]:




