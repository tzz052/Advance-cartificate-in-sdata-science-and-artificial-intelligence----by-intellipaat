# Capstone-Project-1

A capstone Project that was a part of my MOOC held by Intellipaat. It was designed to test whether the learner has grasped the basics of Python and Data Science.

To be more specific, it deals with topics like Data Manipulation, Data Visualization and Model Building using different algorithms. The built models were also evaluated using accuracy metrics 

