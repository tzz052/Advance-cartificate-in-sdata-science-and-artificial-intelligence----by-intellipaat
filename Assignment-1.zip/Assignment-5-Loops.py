a=[]
n=int(input("Number of elements in array:"))
for i in range(0,n):
    l=int(input())
    if l>1:
        for j in range(2,l):
            if l%j==0:
                break
        else:
            a.append(l)
    else:
        a.append(l)
print(a)
