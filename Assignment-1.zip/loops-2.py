#!/usr/bin/env python
# coding: utf-8

# In[11]:


ls = [10,23,4,26,4,75,24,54]
n=0
while(n<len(ls)):
    if (ls[n] % 2 == 0):
        print(ls[n])
    n = n+1


# In[ ]:




