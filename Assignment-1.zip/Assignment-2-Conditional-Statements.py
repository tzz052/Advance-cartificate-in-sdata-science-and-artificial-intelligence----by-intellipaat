num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
num3 = int(input("Enter the third number: "))

if ((num1>num2) & (num1>=num3)):
    print("{} is greatest number.".format(num1))

elif ((num2>num3) & (num2>=num1)):
    print("{} is greatest number.".format(num2))

elif ((num3>num1) & (num3>=num2)):
    print("{} is greatest number.".format(num3))
    
else:
    print("All numbers are equal and number is {}.".format(num1))




