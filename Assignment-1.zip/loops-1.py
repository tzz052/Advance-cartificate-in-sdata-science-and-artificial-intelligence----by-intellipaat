#!/usr/bin/env python
# coding: utf-8

# In[2]:


n=1
while (n<=10):
    print(n)
    n = n+1


# In[ ]:




