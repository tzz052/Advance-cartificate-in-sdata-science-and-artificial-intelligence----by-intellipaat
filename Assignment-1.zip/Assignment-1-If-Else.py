a=10
b=20
if a>b:
    print("a is greater number and number is {}".format(a))
else:
    print("b is greater number and number is {}.".format(b))
